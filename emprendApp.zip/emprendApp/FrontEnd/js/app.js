/* ==========================================================================
   APP.JS — Lógica principal e interactividad de EmprendApp
   --------------------------------------------------------------------------
   Punto de entrada de la aplicación. Conecta el estado (state.js), la
   navegación (navigation.js) y las animaciones (animations.js) con cada
   pantalla. Organizado por pantalla para facilitar el mantenimiento.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  AppState.load();
  Navigation.bindGotoLinks();
  initTheme();
  initMicrointeractions();

  initSplash();
  initLogin();
  initRecoverPassword();
  initRegister();
  initRubro();
  initInsumos();
  initCostos();
  initCalculos();
  initEstadisticas();
  initPerfil();
  initDrawer();

  // Refresca los datos dinámicos de cada pantalla justo antes de mostrarla
  document.addEventListener('screen:before-show', (e) => {
    if (e.detail.screen === 'insumos') cargarInsumosDesdeBD();
    if (e.detail.screen === 'costos') renderCostos();
    if (e.detail.screen === 'calculos') renderCalculos();
    if (e.detail.screen === 'estadisticas') renderEstadisticas();
    if (e.detail.screen === 'perfil') renderPerfil();
  });
});

/* ========================================================================
 * MENÚ LATERAL (DRAWER) — hamburguesa, cierre por X / backdrop / enlace
 * ===================================================================== */
function initDrawer() {
  const overlay = document.querySelector('.js-drawer-overlay');
  const hamburgerBtn = document.querySelector('.js-hamburger');
  const closeBtn = document.querySelector('.js-drawer-close');
  const drawerLinks = document.querySelectorAll('.js-drawer-link');

  function openDrawer() {
    overlay?.classList.add('is-open');
    hamburgerBtn?.classList.add('is-open');
    hamburgerBtn?.setAttribute('aria-expanded', 'true');
  }

  function closeDrawer() {
    overlay?.classList.remove('is-open');
    hamburgerBtn?.classList.remove('is-open');
    hamburgerBtn?.setAttribute('aria-expanded', 'false');
  }

  hamburgerBtn?.addEventListener('click', () => {
    const isOpen = overlay?.classList.contains('is-open');
    isOpen ? closeDrawer() : openDrawer();
  });

  closeBtn?.addEventListener('click', closeDrawer);

  // Cierra al hacer clic fuera del panel (sobre el backdrop semitransparente)
  overlay?.addEventListener('click', (e) => {
    if (e.target === overlay) closeDrawer();
  });

  // Cierra el drawer al navegar a cualquier sección desde sus enlaces
  drawerLinks.forEach((link) => link.addEventListener('click', closeDrawer));

  // Cierra con la tecla Escape, por accesibilidad
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeDrawer();
  });

  // Conecta todos los botones de "Cerrar sesión" (drawer y pantalla de Perfil)
  document.querySelectorAll('.js-logout').forEach((btn) => {
    btn.addEventListener('click', () => {
      closeDrawer();
      logout();
    });
  });
}

/**
 * Cierra la sesión simulada: limpia el flag de login en el estado y
 * vuelve a la pantalla de Login. Se usa desde el botón del drawer y
 * desde el botón de la pantalla de Perfil.
 */
function logout() {
  // TODO: Reemplazar con fetch('/api/v1/logout', { method: 'POST' })
  AppState.data.user.isLoggedIn = false;
  AppState.save();
  Navigation.goTo('login');
  Animations.showToast('Sesión cerrada correctamente');
}

/* ========================================================================
 * 1. SPLASH SCREEN
 * ===================================================================== */
function initSplash() {
  const splash = document.getElementById('screen-splash');
  let hasNavigated = false;

  function goToLogin() {
    if (hasNavigated) return;
    hasNavigated = true;
    splash.classList.add('is-leaving');
    setTimeout(() => Navigation.goTo('login'), 480);
  }

  // Navega automáticamente luego de 2.5s
  setTimeout(goToLogin, 2500);
  // O al hacer clic/touch en cualquier parte de la pantalla
  splash.addEventListener('click', goToLogin);
}

/* ========================================================================
 * 2. LOGIN
 * ===================================================================== */
function initLogin() {
  const form = document.querySelector('.js-login-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const emailInput = form.querySelector('.js-input-email');
    const passwordInput = form.querySelector('.js-input-password');

    const emailOk = validateEmail(emailInput);
    const passwordOk = validateRequired(passwordInput);

    if (!emailOk || !passwordOk) return;

    // TODO: Reemplazar con fetch('/api/v1/login', { method: 'POST', body: {...} })
    AppState.login(emailInput.value.trim());
    Animations.showToast('¡Bienvenido/a de nuevo!');

    // Si el usuario ya tiene un rubro elegido, va directo a Insumos.
    // Si es su primera vez, lo llevamos al flujo de onboarding (rubro).
    const target = AppState.data.user.rubro ? 'insumos' : 'rubro';
    setTimeout(() => Navigation.goTo(target), 400);
  });
}

/* ========================================================================
 * 3 y 4. RECUPERAR CONTRASEÑA (solicitar código + restablecer)
 * ===================================================================== */
function initRecoverPassword() {
  const recoverForm = document.querySelector('.js-recover-form');
  const otpModal = document.querySelector('.js-modal-otp');
  const otpCancelBtn = document.querySelector('.js-modal-otp-cancel');
  const otpConfirmBtn = document.querySelector('.js-modal-otp-confirm');
  const otpInputs = document.querySelectorAll('.otp-group__input');
  const resetForm = document.querySelector('.js-reset-form');

  if (recoverForm) {
    recoverForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = recoverForm.querySelector('.js-input-email');
      if (!validateEmail(emailInput)) return;

      // TODO: Reemplazar con fetch('/api/v1/recover/request-code', { method: 'POST', body: {...} })
      Animations.openModal(otpModal);
      otpInputs.forEach((i) => (i.value = ''));
      otpInputs[0]?.focus();
    });
  }

  // Auto-avanza el foco al siguiente input de OTP
  otpInputs.forEach((input, idx) => {
    input.addEventListener('input', () => {
      if (input.value && idx < otpInputs.length - 1) {
        otpInputs[idx + 1].focus();
      }
    });
  });

  otpCancelBtn?.addEventListener('click', () => Animations.closeModal(otpModal));

  otpConfirmBtn?.addEventListener('click', () => {
    // TODO: Reemplazar con fetch('/api/v1/recover/verify-code', { method: 'POST', body: {...} })
    Animations.closeModal(otpModal);
    Animations.showToast('Código verificado correctamente');
    Navigation.goTo('recover-reset');
  });

  if (resetForm) {
    resetForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const passInput = resetForm.querySelector('.js-input-password');
      const repeatInput = resetForm.querySelector('.js-input-password-repeat');

      const passOk = validateMinLength(passInput, 6);
      const matchOk = validatePasswordsMatch(passInput, repeatInput);
      if (!passOk || !matchOk) return;

      // TODO: Reemplazar con fetch('/api/v1/recover/reset', { method: 'POST', body: {...} })
      Animations.showToast('Contraseña actualizada con éxito');
      resetForm.reset();
      setTimeout(() => Navigation.goTo('login'), 400);
    });
  }
}

/* ========================================================================
 * 5. REGISTRO — DATOS PERSONALES
 * ===================================================================== */
function initRegister() {
  const form = document.querySelector('.js-register-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const nameInput = form.querySelector('.js-input-name');
    const emailInput = form.querySelector('.js-input-email');
    const passInput = form.querySelector('.js-input-password');
    const repeatInput = form.querySelector('.js-input-password-repeat');

    const nameOk = validateRequired(nameInput);
    const emailOk = validateEmail(emailInput);
    const passOk = validateMinLength(passInput, 6);
    const matchOk = validatePasswordsMatch(passInput, repeatInput);

    if (!nameOk || !emailOk || !passOk || !matchOk) return;

    // TODO: Reemplazar con fetch('/api/v1/register', { method: 'POST', body: {...} })
    AppState.registerUser({ name: nameInput.value.trim(), email: emailInput.value.trim() });
    Navigation.goTo('rubro');
  });
}

/* ========================================================================
 * 6. SELECCIÓN DE RUBRO
 * ===================================================================== */
/**
 * Flag: true justo después de terminar el registro (datos + rubro).
 * Lo lee renderPerfil() para abrir la pantalla de Perfil ya en modo
 * edición, así el usuario revisa y ajusta sus datos de inmediato.
 */
let justRegistered = false;

function initRubro() {
  const cards = document.querySelectorAll('.js-rubro-card');
  const confirmBtn = document.querySelector('.js-confirm-rubro');
  let selectedRubro = null;

  cards.forEach((card) => {
    card.addEventListener('click', () => {
      cards.forEach((c) => c.classList.remove('is-selected'));
      card.classList.add('is-selected');
      selectedRubro = card.getAttribute('data-rubro');
      confirmBtn.disabled = false;
    });
  });

  confirmBtn?.addEventListener('click', () => {
    if (!selectedRubro) return;
    // TODO: Reemplazar con fetch('/api/v1/me/rubro', { method: 'PATCH', body: {...} })
    AppState.setRubro(selectedRubro);
    Animations.showToast('¡Cuenta creada! Revisá tus datos.');

    // Flujo post-registro: en vez de ir directo a Insumos, llevamos al
    // usuario a revisar/ajustar su perfil recién creado.
    justRegistered = true;
    setTimeout(() => Navigation.goTo('perfil'), 350);
  });
}

/* ========================================================================
 * 7. INSUMOS
 * ===================================================================== */
  function initInsumos() {
    const modal = document.querySelector('.js-modal-insumo');
    const modalTitle = document.querySelector('.js-modal-insumo-title');
    // Apuntamos DIRECTO al id de tu formulario visible
    const form = document.querySelector('#form-marroquineria');
    const nombreInput = document.querySelector('.js-insumo-nombre');
    const precioInput = document.querySelector('.js-insumo-precio');
    const openBtn = document.querySelector('.js-open-insumo-modal');
    const cancelBtn = document.querySelector('.js-modal-insumo-cancel');
    const searchInput = document.querySelector('.js-search-insumo');

    let editingId = null; // null = modo "crear", string/number = modo "editar"

    // Abrir modal de nuevo insumo
    openBtn?.addEventListener('click', (e) => {
      e?.preventDefault();
      editingId = null;
      if (modalTitle) modalTitle.textContent = 'Nuevo insumo';
      form?.reset();
      if (modal) Animations.openModal(modal);
      nombreInput?.focus();
    });

    // Cancelar modal
    cancelBtn?.addEventListener('click', () => {
      if (modal) Animations.closeModal(modal);
    });
// Enviar formulario (Crear o Editar Producto de Marroquinería)
    form?.addEventListener('submit', async (e) => {
      console.log('--- ¡FORMULARIO CAPTURADO! ---'); // <--- LÍNEA DE PRUEBA
      e.preventDefault();

      // FormData toma automáticamente TODOS los inputs del formulario HTML
      const formData = new FormData(form);
      if (editingId) formData.append('id', editingId);

      try {
        const response = await fetch('../guardar_insumo.php', {
          method: 'POST',
          body: formData
        });
        const data = await response.json();

        if (data.status === 'success') {
          Animations.showToast(editingId ? 'Producto actualizado' : 'Producto guardado');
          Animations.closeModal(modal);
          form.reset();
          cargarInsumosDesdeBD(); // Recarga la lista
        } else {
          alert('Error al guardar: ' + (data.message || 'Ocurrió un problema'));
        }
      } catch (err) {
        console.error('Error de conexión al guardar producto:', err);
      }
    });

    // Buscador de insumos
    searchInput?.addEventListener('input', () => {
      // Si querés filtrar, podemos adaptar el listado o filtrar visualmente
    });

    // Eventos de Editar y Eliminar en la lista
    document.querySelector('.js-insumos-list')?.addEventListener('click', async (e) => {
      const editBtn = e.target.closest('.js-edit-insumo') || e.target.closest('.js-borrar-insumo');
      const deleteBtn = e.target.closest('.js-delete-insumo') || e.target.closest('.js-borrar-insumo');
      const emptyAddBtn = e.target.closest('.js-empty-add-insumo');

      if (emptyAddBtn) {
        openBtn?.click();
        return;
      }

      // ELIMINAR INSUMO
      if (deleteBtn) {
        const id = deleteBtn.getAttribute('data-id');
        const itemEl = deleteBtn.closest('.list-item') || deleteBtn.closest('div');

        if (confirm('¿Seguro que querés eliminar este insumo?')) {
          const formData = new FormData();
          formData.append('id', id);

          try {
            const res = await fetch('../borrar_insumo.php', { method: 'POST', body: formData });
            const data = await res.json();

            if (data.status === 'success') {
              if (itemEl && typeof Animations !== 'undefined' && Animations.removeListItem) {
                await Animations.removeListItem(itemEl);
              }
              Animations.showToast('Insumo eliminado', 'error');
              cargarInsumosDesdeBD();
            } else {
              alert('Error al borrar: ' + data.message);
            }
          } catch (err) {
            console.error('Error al borrar:', err);
          }
        }
      }
    });
  }
function renderInsumos(filter = '') {
  const list = document.querySelector('.js-insumos-list');
  if (!list) return;

  const term = filter.trim().toLowerCase();
  const items = AppState.data.insumos.filter((i) => i.nombre.toLowerCase().includes(term));

  if (items.length === 0) {
    list.innerHTML = AppState.data.insumos.length === 0
      ? renderEmptyState({
          icon: '📦',
          title: 'No tenés insumos agregados todavía',
          desc: 'Cargá tus materiales y precios para empezar a calcular tus costos.',
          ctaLabel: '+ Agregar primer insumo',
          ctaClass: 'js-empty-add-insumo',
        })
      : renderEmptyState({
          icon: '🔍',
          title: 'No se encontraron insumos',
          desc: `Ningún resultado para "${filter.trim()}".`,
        });
    return;
  }

  list.innerHTML = items.map((i) => `
    <div class="list-item" data-id="${i.id}">
      <div class="list-item__info">
        <div class="list-item__title">${escapeHtml(i.nombre)}</div>
      </div>
      <div class="list-item__price">$${formatNumber(i.precio)}</div>
      <div class="list-item__actions">
        <button class="list-item__action-btn js-edit-insumo" data-id="${i.id}" aria-label="Editar">✏️</button>
        <button class="list-item__action-btn list-item__action-btn--danger js-delete-insumo" data-id="${i.id}" aria-label="Eliminar">🗑️</button>
      </div>
    </div>
  `).join('');
}
//* ========================================================================
 //* 8. COSTOS (FIJOS Y VARIABLES CON MYSQL)
 //* ===================================================================== *//
let tipoCostoActual = 'fijo';
let totalFijosMonto = 0;
let totalVariablesMonto = 0;

function initCostos() {
  cargarCostosFijosDesdeBD();
  cargarCostosVariablesDesdeBD();

  // Delegación de eventos para clics globales
  document.addEventListener('click', (e) => {
    // 1. Cambio de pestañas (Fijos / Variables / Desglose)
    const tabBtn = e.target.closest('.js-cost-tabs .tabs__btn');
    if (tabBtn) {
      const tab = tabBtn.getAttribute('data-tab');
      document.querySelectorAll('.js-cost-tabs .tabs__btn').forEach((b) => b.classList.remove('is-active'));
      tabBtn.classList.add('is-active');
      document.querySelectorAll('.tab-panel').forEach((p) => {
        p.classList.toggle('is-active', p.getAttribute('data-tab-panel') === tab);
      });
    }

    // 2. Abrir Modal de Costos (detecta si es fijo o variable)
    const openBtn = e.target.closest('.js-open-costo-modal');
    if (openBtn) {
      tipoCostoActual = openBtn.getAttribute('data-tipo') || 'fijo';
      const modal = document.querySelector('.js-modal-costo');
      const titleEl = modal?.querySelector('.modal__title');
      if (titleEl) {
        titleEl.textContent = tipoCostoActual === 'variable' ? 'Nuevo costo variable' : 'Nuevo costo fijo';
      }
      const form = document.querySelector('.js-costo-form');
      form?.reset();
      if (modal) modal.classList.add('is-open');
    }

    // 3. Cerrar Modal de Costos
    if (e.target.closest('.js-modal-costo-cancel')) {
      const modal = document.querySelector('.js-modal-costo');
      if (modal) modal.classList.remove('is-open');
    }
  });

  // 4. Guardar costo (Fijo o Variable) según corresponda
  const form = document.querySelector('.js-costo-form');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(form);

    // Si es variable, enviamos también el parámetro 'precio' por si el PHP de insumos lo requiere
    if (tipoCostoActual === 'variable') {
      const monto = formData.get('monto');
      if (monto) formData.append('precio', monto);
    }

    const endpoint = tipoCostoActual === 'variable' 
      ? '../guardar_insumo.php' 
      : '../guardar_costo_fijo.php';

    try {
      const res = await fetch(endpoint, { method: 'POST', body: formData });
      const data = await res.json();

      if (data.status === 'success') {
        const modal = document.querySelector('.js-modal-costo');
        if (modal) modal.classList.remove('is-open');
        form.reset();

        if (tipoCostoActual === 'variable') {
          cargarCostosVariablesDesdeBD();
        } else {
          cargarCostosFijosDesdeBD();
        }
      } else {
        alert('Error: ' + data.message);
      }
    } catch (err) {
      console.error('Error al guardar costo:', err);
    }
  });

  // 5. Eliminar Costo Fijo
  document.addEventListener('click', async (e) => {
    const deleteFijoBtn = e.target.closest('.js-borrar-costo-fijo');
    if (deleteFijoBtn) {
      const id = deleteFijoBtn.getAttribute('data-id');
      if (confirm('¿Seguro que querés eliminar este costo fijo?')) {
        const formData = new FormData();
        formData.append('id', id);
        try {
          const res = await fetch('../borrar_costo_fijo.php', { method: 'POST', body: formData });
          const data = await res.json();
          if (data.status === 'success') cargarCostosFijosDesdeBD();
        } catch (err) {
          console.error('Error al borrar costo fijo:', err);
        }
      }
    }

    // 6. Eliminar Costo Variable (Insumo)
    const deleteVarBtn = e.target.closest('.js-borrar-insumo');
    if (deleteVarBtn) {
      const id = deleteVarBtn.getAttribute('data-id');
      if (confirm('¿Seguro que querés eliminar este costo variable?')) {
        const formData = new FormData();
        formData.append('id', id);
        try {
          const res = await fetch('../borrar_insumo.php', { method: 'POST', body: formData });
          const data = await res.json();
          if (data.status === 'success') cargarCostosVariablesDesdeBD();
        } catch (err) {
          console.error('Error al borrar costo variable:', err);
        }
      }
    }
  });
}

// Cargar Costos Fijos
async function cargarCostosFijosDesdeBD() {
  try {
    const res = await fetch('../obtener_costos_fijos.php');
    const costos = await res.json();
    renderCostosFijosList(costos);
  } catch (err) {
    console.error('Error cargando costos fijos:', err);
  }
}

function renderCostosFijosList(costos) {
  const list = document.querySelector('.js-costos-fijos-list');
  const totalEl = document.querySelector('.js-total-fijos');
  const diarioEl = document.querySelector('.js-costo-diario');
  if (!list) return;

  totalFijosMonto = 0;

  if (!Array.isArray(costos) || costos.length === 0) {
    list.innerHTML = `
      <div class="u-text-center u-p-md">
        <p class="u-text-secondary">Todavía no agregaste costos fijos</p>
      </div>
    `;
  } else {
    list.innerHTML = costos.map((c) => {
      const monto = Number(c.monto || 0);
      totalFijosMonto += monto;
      return `
        <div class="list-item" data-id="${c.id}">
          <div class="list-item__info">
            <div class="list-item__title">${c.nombre || c.concepto || 'Costo fijo'}</div>
          </div>
          <div class="list-item__price">$${monto.toLocaleString('es-AR')}</div>
          <div class="list-item__actions">
            <button class="list-item__action-btn list-item__action-btn--danger js-borrar-costo-fijo" data-id="${c.id}" aria-label="Eliminar">🗑️</button>
          </div>
        </div>
      `;
    }).join('');
  }

  if (totalEl) totalEl.textContent = '$' + totalFijosMonto.toLocaleString('es-AR');
  if (diarioEl) diarioEl.textContent = '$' + Math.round(totalFijosMonto / 30).toLocaleString('es-AR');
  actualizarDesglose();
}

// Cargar Costos Variables (Insumos)
// Cargar Costos Variables (Insumos)
async function cargarCostosVariablesDesdeBD() {
  try {
    const res = await fetch('../obtener_insumos.php');
    const respuesta = await res.json();

    // Acá está la magia: buscamos el listado sin importar cómo lo envuelva el PHP
    let insumosArray = [];
    if (Array.isArray(respuesta)) {
      insumosArray = respuesta;
    } else if (respuesta && Array.isArray(respuesta.data)) {
      insumosArray = respuesta.data;
    } else if (respuesta && Array.isArray(respuesta.insumos)) {
      insumosArray = respuesta.insumos;
    }

    renderCostosVariablesList(insumosArray);
  } catch (err) {
    console.error('Error cargando costos variables:', err);
  }
}

function renderCostosVariablesList(insumos) {
  const list = document.querySelector('.js-costos-variables-list');
  if (!list) return;

  totalVariablesMonto = 0;

  if (!Array.isArray(insumos) || insumos.length === 0) {
    list.innerHTML = `
      <div class="u-text-center u-p-md">
        <p class="u-text-secondary">Todavía no agregaste costos variables</p>
      </div>
    `;
  } else {
    list.innerHTML = insumos.map((i) => {
      const precio = Number(i.precio || i.monto || 0);
      totalVariablesMonto += precio;
      const id = i.id || i.id_insumo || i.id_producto;
      return `
        <div class="list-item" data-id="${id}">
          <div class="list-item__info">
            <div class="list-item__title">${i.nombre || i.concepto || 'Insumo'}</div>
          </div>
          <div class="list-item__price">$${precio.toLocaleString('es-AR')}</div>
          <div class="list-item__actions">
            <button class="list-item__action-btn list-item__action-btn--danger js-borrar-insumo" data-id="${id}" aria-label="Eliminar">🗑️</button>
          </div>
        </div>
      `;
    }).join('');
  }

  actualizarDesglose();
}

// Actualizar pestaña de Desglose Total
function actualizarDesglose() {
  const fijosEl = document.querySelector('.js-desglose-fijos');
  const variablesEl = document.querySelector('.js-desglose-variables');
  const totalEl = document.querySelector('.js-desglose-total');

  const totalGeneral = totalFijosMonto + totalVariablesMonto;

  if (fijosEl) fijosEl.textContent = '$' + totalFijosMonto.toLocaleString('es-AR');
  if (variablesEl) variablesEl.textContent = '$' + totalVariablesMonto.toLocaleString('es-AR');
  if (totalEl) totalEl.textContent = '$' + totalGeneral.toLocaleString('es-AR');
}

function renderCostos() {
  cargarCostosFijosDesdeBD();
  cargarCostosVariablesDesdeBD();
}

/* ========================================================================
 * 9. CÁLCULOS Y PRECIO DE VENTA
 * ===================================================================== */
function initCalculos() {
  const slider = document.querySelector('.js-margen-slider');
  const saveBtn = document.querySelector('.js-save-calculos');

  slider?.addEventListener('input', () => {
    updateCalculosDisplay();
  });

  saveBtn?.addEventListener('click', async () => {
    const idProducto = document.querySelector('#js-producto-id')?.value || '13';
    const precioSugeridoTexto = document.querySelector('.js-precio-sugerido')?.textContent || '0';
    const precioSugerido = precioSugeridoTexto.replace(/[^0-9]/g, '');

    const formData = new FormData();
    formData.append('id_producto', idProducto);
    formData.append('precio_sugerido', precioSugerido);

    try {
      const response = await fetch('../guardar_calculo.php', { method: 'POST', body: formData });
      const data = await response.json();
      if (data.status === 'success') {
        alert('Cálculos guardados correctamente');
      } else {
        alert('Error: ' + data.message);
      }
    } catch (error) {
      console.error('Error guardando cálculos:', error);
    }
  });
}

function renderCalculos() {
  const costoUnidadEl = document.querySelector('.js-costo-unidad');
  if (costoUnidadEl && (costoUnidadEl.textContent === '$0' || costoUnidadEl.textContent === '0')) {
    costoUnidadEl.textContent = '$5.000'; // Valor base de prueba
  }
  updateCalculosDisplay();
}

function updateCalculosDisplay() {
  const slider = document.querySelector('.js-margen-slider');
  const margenBadge = document.querySelector('.js-margen-badge');
  const inputCosto = document.querySelector('.js-costo-unitario-input');
  const precioEl = document.querySelector('.js-precio-sugerido');
  const gananciaEl = document.querySelector('.js-ganancia');
  const puntoEquilibrioEl = document.querySelector('.js-punto-equilibrio');

  const margen = slider ? Number(slider.value) : 40;
  if (margenBadge) margenBadge.textContent = margen + '%';

  // Leer el valor directamente del input que creamos
  let costoBase = inputCosto ? (parseFloat(inputCosto.value) || 0) : 5000;

  const ganancia = Math.round(costoBase * (margen / 100));
  const precioSugerido = costoBase + ganancia;

  // Punto de equilibrio con costos fijos
  let fijos = (typeof totalFijosMonto !== 'undefined' && totalFijosMonto > 0) ? totalFijosMonto : 37400;
  let unidadesEquilibrio = ganancia > 0 ? Math.ceil(fijos / ganancia) : 0;

  if (precioEl) precioEl.textContent = '$' + precioSugerido.toLocaleString('es-AR');
  if (gananciaEl) gananciaEl.textContent = '$' + ganancia.toLocaleString('es-AR');
  if (puntoEquilibrioEl) puntoEquilibrioEl.textContent = unidadesEquilibrio + ' unid.';
}

/* ========================================================================
 * 10. ESTADÍSTICAS / DASHBOARD
 * ===================================================================== */
function initEstadisticas() {
  // Esta pantalla es principalmente de lectura; su interactividad
  // (botón de engranaje) ya está resuelta por Navigation.bindGotoLinks().
}

function renderEstadisticas() {
  const { estadisticas } = AppState.data;

  document.querySelector('.js-periodo').textContent = estadisticas.periodo;

  Animations.countUp(document.querySelector('.js-kpi-ingresos'), estadisticas.ingresos);
  Animations.countUp(document.querySelector('.js-kpi-costos'), estadisticas.costos);

  const margenPct = estadisticas.ingresos > 0
    ? Math.round(((estadisticas.ingresos - estadisticas.costos) / estadisticas.ingresos) * 1000) / 10
    : 0;
  const margenEl = document.querySelector('.js-kpi-margen');
  if (margenEl) margenEl.textContent = margenPct + '%';

  renderBarChart(estadisticas.ingresosPorMes);
  renderRankList(estadisticas.productosRentables);
}

function renderBarChart(meses) {
  const container = document.querySelector('.js-bar-chart');
  if (!container) return;

  if (meses.length === 0) {
    container.innerHTML = renderEmptyState({
      icon: '📊',
      title: 'Todavía no hay ingresos cargados',
      desc: 'A medida que registres ventas vas a ver la evolución mes a mes acá.',
      inline: true,
    });
    return;
  }

  const isLast = (i) => i === meses.length - 1;

  container.innerHTML = meses.map((m, i) => `
    <div class="bar-chart__col">
      <div class="bar-chart__bar${isLast(i) ? ' is-current' : ''}" style="height:0%"></div>
      <span class="bar-chart__label">${escapeHtml(m.mes)}</span>
    </div>
  `).join('');

  // Se dispara luego del render para que la transición de height sea visible
  requestAnimationFrame(() => {
    Animations.growBars(container, meses.map((m) => m.valor));
  });
}

function renderRankList(productos) {
  const container = document.querySelector('.js-rank-list');
  if (!container) return;

  if (productos.length === 0) {
    container.innerHTML = renderEmptyState({
      icon: '🏆',
      title: 'Sin productos rentables todavía',
      desc: 'Cuando registres ventas, acá vas a ver tu ranking de productos.',
      inline: true,
    });
    return;
  }

  container.innerHTML = productos.map((p) => `
    <div class="rank-item">
      <div class="rank-item__top">
        <span class="rank-item__name">${escapeHtml(p.nombre)}</span>
        <span class="rank-item__pct">${p.porcentaje}%</span>
      </div>
      <div class="progress-track">
        <div class="progress-fill" style="width:0%" data-target-pct="${p.porcentaje}"></div>
      </div>
    </div>
  `).join('');

  requestAnimationFrame(() => {
    container.querySelectorAll('.progress-fill').forEach((el) => {
      Animations.growProgress(el, Number(el.getAttribute('data-target-pct')));
    });
  });
}

/* ========================================================================
 * 11. CONFIGURACIÓN / MI PERFIL (mock)
 * ===================================================================== */
/**
 * Activa/desactiva el modo edición de la pantalla de Perfil. Se expone
 * fuera de initPerfil() porque también se usa justo después de terminar
 * el registro, para que el usuario revise sus datos de una.
 */
function setPerfilEditMode(isEditing) {
  const editarBtn = document.querySelector('.js-perfil-editar');
  const guardarBtn = document.querySelector('.js-perfil-guardar');
  const inputs = document.querySelectorAll('.js-perfil-nombre, .js-perfil-email, .js-perfil-rubro');

  inputs.forEach((input) => (input.disabled = !isEditing));
  if (editarBtn) editarBtn.style.display = isEditing ? 'none' : '';
  if (guardarBtn) guardarBtn.style.display = isEditing ? '' : 'none';
}

function initPerfil() {
  const form = document.querySelector('.js-perfil-form');
  const editarBtn = document.querySelector('.js-perfil-editar');
  const nombreInput = document.querySelector('.js-perfil-nombre');
  const emailInput = document.querySelector('.js-perfil-email');
  const rubroInput = document.querySelector('.js-perfil-rubro');

  editarBtn?.addEventListener('click', () => {
    setPerfilEditMode(true);
    nombreInput?.focus();
  });

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    const nameOk = validateRequired(nombreInput);
    const emailOk = validateEmail(emailInput);
    if (!nameOk || !emailOk) return;

    AppState.updateProfile({
      name: nombreInput.value.trim(),
      email: emailInput.value.trim(),
      rubro: rubroInput.value,
    });

    setPerfilEditMode(false);
    Animations.showToast('Datos actualizados correctamente');
  });
}

function renderPerfil() {
  const { user } = AppState.data;
  const nombreEl = document.querySelector('.js-perfil-nombre');
  const emailEl = document.querySelector('.js-perfil-email');
  const rubroEl = document.querySelector('.js-perfil-rubro');

  if (nombreEl) nombreEl.value = user.name || '';
  if (emailEl) emailEl.value = user.email || '';
  if (rubroEl && user.rubro) rubroEl.value = user.rubro;

  // Justo después de registrarse arranca en modo edición, para que el
  // usuario revise/ajuste sus datos de una; en cualquier otro caso
  // (navegación normal desde el menú) arranca en modo lectura.
  setPerfilEditMode(Boolean(justRegistered));
  if (justRegistered) justRegistered = false;
}

/* ========================================================================
 * MODO CLARO / OSCURO (theme toggle)
 * ===================================================================== */
const THEME_STORAGE_KEY = 'emprendapp_theme';

function initTheme() {
  const root = document.documentElement;
  const toggleBtns = document.querySelectorAll('.js-theme-toggle');

  // TODO: cuando exista backend real, la preferencia de tema podría
  // guardarse en el perfil del usuario en vez de (o además de) localStorage.
  let saved = 'dark';
  try {
    saved = localStorage.getItem(THEME_STORAGE_KEY) || 'dark';
  } catch (err) {
    console.warn('No se pudo leer la preferencia de tema.', err);
  }

  applyTheme(saved);

  function applyTheme(theme) {
    root.setAttribute('data-theme', theme);
    toggleBtns.forEach((btn) => {
      btn.textContent = theme === 'light' ? '🌙' : '☀️';
      btn.setAttribute('aria-label', theme === 'light' ? 'Cambiar a modo oscuro' : 'Cambiar a modo claro');
    });
  }

  toggleBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      const isLight = root.getAttribute('data-theme') === 'light';
      const next = isLight ? 'dark' : 'light';
      applyTheme(next);
      try {
        localStorage.setItem(THEME_STORAGE_KEY, next);
      } catch (err) {
        console.warn('No se pudo guardar la preferencia de tema.', err);
      }
    });
  });
}

/* ========================================================================
 * MICROINTERACCIONES — efecto "ripple" al hacer clic en botones
 * ===================================================================== */
function initMicrointeractions() {
  const RIPPLE_SELECTOR = '.btn, .btn-fab, .btn-icon-round, .theme-toggle-btn, .select-card, .tabs__btn, .list-item__action-btn';

  document.addEventListener('click', (e) => {
    const target = e.target.closest(RIPPLE_SELECTOR);
    if (!target || target.disabled) return;
    Animations.spawnRipple(target, e);
  });
}

/* ========================================================================
 * VALIDACIONES DE FORMULARIO (helpers reutilizables)
 * ===================================================================== */
function showFieldError(input, show) {
  const errorEl = input.closest('.field')?.querySelector('.field__error');
  input.classList.toggle('field__input--invalid', show);
  if (errorEl) errorEl.classList.toggle('is-visible', show);
  return !show;
}

function validateRequired(input) {
  const ok = input.value.trim().length > 0;
  return showFieldError(input, !ok);
}

function validateEmail(input) {
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim());
  return showFieldError(input, !ok);
}

function validateMinLength(input, min) {
  const ok = input.value.trim().length >= min;
  return showFieldError(input, !ok);
}

function validatePasswordsMatch(passInput, repeatInput) {
  const ok = passInput.value === repeatInput.value && repeatInput.value.length > 0;
  return showFieldError(repeatInput, !ok);
}

/**
 * Genera el markup de un "empty state" elegante y reutilizable:
 * ícono en círculo, título, descripción opcional y CTA opcional.
 * @param {Object} opts
 * @param {string} opts.icon - Emoji/ícono central.
 * @param {string} opts.title - Frase principal (ej: "No tenés insumos...").
 * @param {string} [opts.desc] - Texto secundario opcional.
 * @param {string} [opts.ctaLabel] - Texto del botón de acción (si se omite, no hay CTA).
 * @param {string} [opts.ctaClass] - Clase para enganchar el click del CTA vía JS.
 * @param {boolean} [opts.inline] - Usa la variante compacta sin borde/fondo propio.
 */
function renderEmptyState({ icon, title, desc = '', ctaLabel = '', ctaClass = '', inline = false }) {
  return `
    <div class="empty-state${inline ? ' empty-state--inline' : ''}">
      <div class="empty-state__icon-wrap"><span class="empty-state__icon">${icon}</span></div>
      <p class="empty-state__title">${escapeHtml(title)}</p>
      ${desc ? `<p class="empty-state__desc">${escapeHtml(desc)}</p>` : ''}
      ${ctaLabel ? `<button type="button" class="btn btn-primary u-max-w-form empty-state__cta ${ctaClass}">${escapeHtml(ctaLabel)}</button>` : ''}
    </div>`;
}

/** Escapa HTML para prevenir inyección al renderizar texto dinámico. */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

    // --- Funciones Auxiliares (Buenas Prácticas: Modularización) ---

    function cerrarModalInsumo() {
        const modal = document.querySelector('.js-modal-insumo');
        if (modal) {
            modal.classList.remove('is-visible');
            modal.style.display = 'none';
        }
    }

    function dibujarTarjetaInsumo(insumo) {
    const contenedor = document.querySelector('.js-insumos-list');
    if (!contenedor) return;

    // Generamos el HTML exacto con sus clases y data-id
    const tarjetaHTML = `
        <div class="list-item" style="display: flex; justify-content: space-between; align-items: center; padding: 10px; border-bottom: 1px solid #eee;">
            <div>
                <strong>${insumo.nombre}</strong>
                <div style="color: #666;">$${Number(insumo.precio).toLocaleString('es-AR')}</div>
            </div>
            <div>
                <button type="button" class="js-borrar-insumo" data-id="${insumo.id}" style="background: #fee2e2; border: none; padding: 6px 10px; border-radius: 4px; cursor: pointer;">🗑️</button>
            </div>
        </div>
    `;

    // Lo insertamos al final de la lista sin borrar lo anterior y sin recargar
    contenedor.insertAdjacentHTML('beforeend', tarjetaHTML);
}

// --- FUNCIONALIDAD: Guardar Precio Sugerido en el Producto Especificado ---
document.addEventListener('DOMContentLoaded', () => {
    const btnGuardarCalculos = document.querySelector('.js-save-calculos');

    if (btnGuardarCalculos) {
        btnGuardarCalculos.addEventListener('click', async () => {
            // Obtenemos el ID del producto del hidden input
            const idProducto = document.querySelector('#js-producto-id')?.value || '18';
            
            // Obtenemos el precio sugerido generado
            const precioSugeridoTexto = document.querySelector('.js-precio-sugerido')?.textContent || '0';
            const precioSugerido = precioSugeridoTexto.replace(/[^0-9]/g, '');

            const formData = new FormData();
            formData.append('id_producto', idProducto);
            formData.append('precio_sugerido', precioSugerido);

            try {
                const response = await fetch('../guardar_calculo.php', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.status === 'success') {
                    alert(data.message);
                } else {
                    alert('Error: ' + data.message);
                }
            } catch (error) {
                console.error('Error enviando datos:', error);
                alert('No se pudo conectar con el servidor.');
            }
        });
    }

  // BORRAR INSUMO
const listaInsumos = document.querySelector('.js-insumos-list');
if (listaInsumos) {
    listaInsumos.addEventListener('click', async (e) => {
        // Verifica si el clic fue en el botón de borrar
        const btnBorrar = e.target.closest('.js-borrar-insumo');
        if (btnBorrar) {
            const idInsumo = btnBorrar.getAttribute('data-id');
            
            if (confirm('¿Seguro que querés borrar este insumo?')) {
                const formData = new FormData();
                formData.append('id', idInsumo);

                try {
                    const response = await fetch('../borrar_insumo.php', {
                        method: 'POST',
                        body: formData
                    });
                    const data = await response.json();
                    
                    if (data.status === 'success') {
                        cargarInsumosDesdeBD(); // Recarga la lista automáticamente sin F5
                    } else {
                        alert('Error al borrar: ' + data.message);
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            }
        }
    });
}
});

// --- CARGAR INSUMOS DESDE MYSQL ---
async function cargarInsumosDesdeBD() {
    const contenedor = document.querySelector('.js-insumos-list');
    if (!contenedor) return;

    try {
        const response = await fetch('../obtener_insumos.php');
        const resultado = await response.json();

        if (resultado.status === 'success') {
            contenedor.innerHTML = ''; // Limpiamos la lista estática

            resultado.data.forEach(insumo => {
                const item = document.createElement('div');
                item.className = 'insumo-card'; // Mantiene tus estilos
                item.innerHTML = `
                    <span>${insumo.nombre}</span>
                    <strong style="color: #00875a;">$${Number(insumo.precio).toLocaleString('es-AR')}</strong>
                `;
                contenedor.appendChild(item);
            });
        }
    } catch (error) {
        console.error('Error cargando insumos:', error);
    }
}

document.addEventListener('DOMContentLoaded', cargarInsumosDesdeBD);



// CARGAR INSUMOS DESDE MYSQL (Versión con estilos)
async function cargarInsumosDesdeBD() {
    const contenedor = document.querySelector('.js-insumos-list');
    if (!contenedor) return;

    try {
        const response = await fetch('../obtener_insumos.php');
        const resultado = await response.json();

        if (resultado.status === 'success') {
            contenedor.innerHTML = ''; // Limpiamos la lista

            resultado.data.forEach(insumo => {
                const item = document.createElement('div');
                // Intentamos usar las clases genéricas que suelen tener estas tarjetas
                item.style.display = 'flex';
                item.style.alignItems = 'center';
                item.style.gap = '10px';
                item.style.padding = '10px 15px';
                item.style.backgroundColor = 'var(--surface-color, #ffffff)';
                item.style.border = '1px solid var(--border-color, #e0e0e0)';
                item.style.borderRadius = '8px';

                item.innerHTML = `
                    <span style="flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 14px;">
                        ${insumo.nombre}
                    </span>
                    <strong style="color: #00875a; font-size: 14px;">
                        $${Number(insumo.precio).toLocaleString('es-AR')}
                    </strong>
                    <div style="display: flex; gap: 5px;">
                        <button type="button" style="background: #f1f3f5; border: none; padding: 5px; border-radius: 4px; cursor: pointer;">✏️</button>
                        <button type="button" class="js-borrar-insumo" data-id="${insumo.id}" style="background: #fee2e2; border: none; padding: 5px; border-radius: 4px; cursor: pointer;">🗑️</button>
                    </div>
                `;
                contenedor.appendChild(item);
            });
        }
    } catch (error) {
        console.error('Error cargando insumos:', error);
    }
}

/* ========================================================================
 * CÁLCULOS DE PRECIO Y PUNTO DE EQUILIBRIO DINÁMICO
 * ===================================================================== */
function actualizarCalculosPrecio() {
  const sliderMargen = document.querySelector('.js-slider-margen');
  const txtMargen = document.querySelector('.js-txt-margen');
  const txtPrecioSugerido = document.querySelector('.js-precio-sugerido');
  const txtGanancia = document.querySelector('.js-ganancia-monto');
  const txtPuntoEquilibrio = document.querySelector('.js-punto-equilibrio');

    // En la línea 1174 de app.js, cambiá "let costoUnitario = 5000;" por:
  const inputCosto = document.querySelector('.js-costo-unitario-input');
  let costoUnitario = inputCosto ? (parseFloat(inputCosto.value) || 0) : 5000;

  let margenPorcentaje = sliderMargen ? parseFloat(sliderMargen.value) : 100;

  if (txtMargen) txtMargen.textContent = margenPorcentaje + '%';

  let gananciaUnitaria = costoUnitario * (margenPorcentaje / 100);
  let precioSugerido = costoUnitario + gananciaUnitaria;

  // Si totalFijosMonto no tiene valor, usá los $37.400 que tenés guardados de la pantalla de Costos
  let fijos = (typeof totalFijosMonto !== 'undefined' && totalFijosMonto > 0) ? totalFijosMonto : 37400;

  let unidadesEquilibrio = 0;
  if (gananciaUnitaria > 0) {
    unidadesEquilibrio = Math.ceil(fijos / gananciaUnitaria);
  }

  if (txtPrecioSugerido) txtPrecioSugerido.textContent = '$' + Math.round(precioSugerido).toLocaleString('es-AR');
  if (txtGanancia) txtGanancia.textContent = 'Ganancia $' + Math.round(gananciaUnitaria).toLocaleString('es-AR');
  if (txtPuntoEquilibrio) txtPuntoEquilibrio.textContent = unidadesEquilibrio + ' unid.';
}

// Escuchar cambios en la barra
document.addEventListener('input', (e) => {
  if (e.target.matches('.js-slider-margen') || e.target.matches('.js-costo-unitario-input')) {
    updateCalculosDisplay();
  }
});

// Ejecutar el cálculo automáticamente al cambiar a la vista de Cálculos
document.addEventListener('click', (e) => {
  if (e.target.closest('.js-goto[data-target="calculos"]')) {
    setTimeout(actualizarCalculosPrecio, 100);
  }
});

// Guardar cálculo de precio en la BD
document.addEventListener('click', async (e) => {
  if (e.target.matches('.js-btn-guardar-calculo') || e.target.textContent.includes('Guardar cambios')) {
    e.preventDefault();

    const sliderMargen = document.querySelector('.js-slider-margen');
    const inputCosto = document.querySelector('.js-costo-unitario-input');
    
    const datos = {
      costo_unitario: inputCosto ? parseFloat(inputCosto.value) || 5000 : 5000,
      margen: sliderMargen ? parseFloat(sliderMargen.value) : 40,
      precio_sugerido: parseFloat(document.querySelector('.js-precio-sugerido')?.textContent.replace(/[^0-9]/g, '')) || 0,
      ganancia: parseFloat(document.querySelector('.js-ganancia-monto')?.textContent.replace(/[^0-9]/g, '')) || 0
    };

    try {
      const res = await fetch('../guardar_calculo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos)
      });
      const respuesta = await res.json();

      if (respuesta.status === 'success') {
        alert('¡Cálculo guardado con éxito!');
      } else {
        alert('Error al guardar el cálculo.');
      }
    } catch (err) {
      console.error('Error guardando cálculo:', err);
      alert('Error de conexión al guardar.');
    }
  }
});

// Carga el cálculo guardado al iniciar la vista
async function cargarCalculoGuardado() {
  try {
    const res = await fetch('../obtener_calculo.php');
    const data = await res.json();

    if (data.status === 'success' && data.precio_sugerido > 0) {
      const txtPrecioSugerido = document.querySelector('.js-precio-sugerido');
      if (txtPrecioSugerido) {
        txtPrecioSugerido.textContent = '$' + Math.round(data.precio_sugerido).toLocaleString('es-AR');
      }
    }
  } catch (err) {
    console.error('Error al obtener cálculo guardado:', err);
  }
}

// Ejecutar la carga al hacer click en ir a cálculos o al cargar la página
document.addEventListener('DOMContentLoaded', cargarCalculoGuardado);
document.addEventListener('click', (e) => {
  if (e.target.closest('[data-target="calculos"]')) {
    cargarCalculoGuardado();
  }
});